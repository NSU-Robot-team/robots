import Command.Command;
import Entity.Entity;

public class Pair {
    Command com;
    Entity ent;

    Pair(Command com, Entity ent) {
        this.com = com;
        this.ent = ent;
    }
}